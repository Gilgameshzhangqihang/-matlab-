%% ----------------------------说明-------------------------- %%
%                            本类为绘制云图
%程序相关变量说明
%    gcf 返回当前Figure对象的句柄值
%    gca 返回当前axes对象的句柄值
%    gco 返回当前鼠标单击的句柄值
%注意：输入数据必须为元胞数组
%%-----------------------------------------------------------------%%
%% ----------------------------代码-------------------------- %% 
classdef ContourPicture < handle
    properties
        %Label设置——坐标轴
        labels=struct('fontName','times new roman',...
                      'fontSize',20,...
                      'X','',...
                      'Y',''); 
        %Graduation设置——坐标刻度
        graduations=struct('fontName','times new roman',...
                           'fontSize',20,...
                           'xlim',[],...
                           'xtick',[],...
                           'ylim',[],...
                           'ytick',[]);
        %line设置——线型
        lines=struct('style','none',...
                     'width',1,...
                     'markerSym','o',...
                     'markerSize',2);
        %Picture设置——图片
        pictures=struct('unit','pixels',...
                        'position',[200 300 1000 600],...
                        'name','Name.bmp',...
                        'format','-dbmp',...
                        'renderer','painters',...
                        'dpi','-r150');
        %数据
        data=struct('X',[],...
                    'Y',[],...
                    'Z',[]);
        %colorbar
        ColorBar=struct('show',true,...
                        'string','',...
                        'location','eastoutside',...
                        'TickLabelInterpreter','none',...
                        'lineNum',10,...
                        'tickLabels',[],...
                        'ticks',[]);
    end
    methods
        %构造函数：只对相关参数进行设置，不执行与绘图相关的操作
        function obj=ContourPicture(xData,yData,zData,xLabelStr,yLabelStr,colorbarStr,name)
            obj.data.X=xData;
            obj.data.Y=yData;
            obj.data.Z=zData;
            obj.labels.X=xLabelStr;
            obj.labels.Y=yLabelStr;
            obj.labels.string=colorbarStr;
            obj.pictures.name=name;
        end
        %保存绘制的图片
        function Save(obj)
            set(gcf,'defaultFigureRenderer',obj.pictures.renderer);   %设置默认渲染器
            print(gcf,obj.pictures.dpi,obj.pictures.format,obj.pictures.name);   %设置输出格式和dpi
        end
        function PlotPicture_contourf(obj)
            hold on
            box on
            axis off
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            xData=cell2mat(obj.data.X);
            yData=cell2mat(obj.data.Y);
            zData=cell2mat(obj.data.Z);
            H=contourf(xData,yData,zData,obj.ColorBar.lineNum,'linestyle',obj.lines.style,'LineWidth',obj.lines.width);
            axis equal;
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            ylabel(obj.labels.Y,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            if(obj.ColorBar.show==true)
                C=colorbar('location',obj.ColorBar.location,'TickLabelInterpreter',obj.ColorBar.TickLabelInterpreter);
                C.Label.Interpreter='latex';
                C.Label.String=obj.labels.string;
                C.Label.FontName=obj.labels.fontName;
                C.Label.FontSize=obj.labels.fontSize;
                C.Label.FontWeight='bold';
                C.FontName=obj.graduations.fontName;
                C.FontSize=obj.graduations.fontSize;
                C.FontWeight='bold';
                %显示范围
                if(isempty(obj.ColorBar.ticks) && isempty(obj.ColorBar.tickLabels))
                elseif(isempty(obj.ColorBar.tickLabels))
                    C.Ticks=obj.ColorBar.ticks;
                else
                    C.Ticks=obj.ColorBar.ticks;
                    C.TickLabels=obj.graduations.tickLabels;
                end
            end
            shading interp
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Y轴的数据显示范围
            if(isempty(obj.graduations.ylim) && isempty(obj.graduations.ytick))
            else
                set(gca,'YLim',obj.graduations.ylim);
                set(gca,'YTick',obj.graduations.ytick);
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
        function PlotPicture_contour(obj)
            hold on
            box on
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            for i=1:length(obj.data.X)
                xData=cell2mat(obj.data.X(i));
                yData=cell2mat(obj.data.Y(i));
                zData=cell2mat(obj.data.Z(i));
                H(i)=contour(xData,yData,zData,obj.ColorBar.lineNum,'linestyle',obj.lines.style,'LineWidth',obj.lines.width);
            end
            axis equal;
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            ylabel(obj.labels.Y,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            if(obj.ColorBar.show==true)
                C=colorbar('location',obj.ColorBar.location,'TickLabelInterpreter',obj.ColorBar.TickLabelInterpreter);
                C.Label.Interpreter='latex';
                C.Label.String=obj.labels.string;
                C.Label.FontName=obj.labels.fontName;
                C.Label.FontSize=obj.labels.fontSize;
                C.Label.FontWeight='bold';
                C.FontName=obj.graduations.fontName;
                C.FontSize=obj.graduations.fontSize;
                C.FontWeight='bold';
                %显示范围
                if(isempty(obj.ColorBar.ticks) && isempty(obj.ColorBar.tickLabels))
                elseif(isempty(obj.ColorBar.tickLabels))
                    C.Ticks=obj.ColorBar.ticks;
                else
                    C.Ticks=obj.ColorBar.ticks;
                    C.TickLabels=obj.graduations.tickLabels;
                end
            end
            shading interp
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Y轴的数据显示范围
            if(isempty(obj.graduations.ylim) && isempty(obj.graduations.ytick))
            else
                set(gca,'YLim',obj.graduations.ylim);
                set(gca,'YTick',obj.graduations.ytick);
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
        function PlotPicture_scatter(obj)
            hold on
            box on
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            xData=cell2mat(obj.data.X);
            yData=cell2mat(obj.data.Y);
            zData=cell2mat(obj.data.Z);
            H=scatter(xData(:),yData(:),obj.lines.markerSize,zData(:),'filled');
            H.Marker=obj.lines.markerSym;
            axis equal;
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            ylabel(obj.labels.Y,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            if(obj.ColorBar.show==true)
                C=colorbar('location',obj.ColorBar.location,'TickLabelInterpreter',obj.ColorBar.TickLabelInterpreter);
                C.Label.Interpreter='latex';
                C.Label.String=obj.labels.string;
                C.Label.FontName=obj.labels.fontName;
                C.Label.FontSize=obj.labels.fontSize;
                C.Label.FontWeight='bold';
                C.FontName=obj.graduations.fontName;
                C.FontSize=obj.graduations.fontSize;
                C.FontWeight='bold';
                %显示范围
                if(isempty(obj.ColorBar.ticks) && isempty(obj.ColorBar.tickLabels))
                elseif(isempty(obj.ColorBar.tickLabels))
                    C.Ticks=obj.ColorBar.ticks;
                else
                    C.Ticks=obj.ColorBar.ticks;
                    C.TickLabels=obj.graduations.tickLabels;
                end
            end
            shading interp
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Y轴的数据显示范围
            if(isempty(obj.graduations.ylim) && isempty(obj.graduations.ytick))
            else
                set(gca,'YLim',obj.graduations.ylim);
                set(gca,'YTick',obj.graduations.ytick);
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
        function PlotPicture_pcolor(obj)
            hold on
            box on
            axis off
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            xData=cell2mat(obj.data.X);
            yData=cell2mat(obj.data.Y);
            zData=cell2mat(obj.data.Z);
            H=pcolor(xData,yData,zData);
            H.EdgeColor='none';
            axis equal
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            ylabel(obj.labels.Y,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            if(obj.ColorBar.show==true)
                C=colorbar('location',obj.ColorBar.location,'TickLabelInterpreter',obj.ColorBar.TickLabelInterpreter);
                C.Label.Interpreter='latex';
                C.Label.String=obj.labels.string;
                C.Label.FontName=obj.labels.fontName;
                C.Label.FontSize=obj.labels.fontSize;
                C.Label.FontWeight='bold';
                C.FontName=obj.graduations.fontName;
                C.FontSize=obj.graduations.fontSize;
                C.FontWeight='bold';
                C.Direction='reverse';
                %显示范围
                if(isempty(obj.ColorBar.ticks) && isempty(obj.ColorBar.tickLabels))
                elseif(isempty(obj.ColorBar.tickLabels))
                    C.Ticks=obj.ColorBar.ticks;
                else
                    C.Ticks=obj.ColorBar.ticks;
                    C.TickLabels=obj.graduations.tickLabels;
                end
            end
            shading interp
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Y轴的数据显示范围
            if(isempty(obj.graduations.ylim) && isempty(obj.graduations.ytick))
            else
                set(gca,'YLim',obj.graduations.ylim);
                set(gca,'YTick',obj.graduations.ytick);
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
    end
end
