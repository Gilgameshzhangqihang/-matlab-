%% ----------------------------说明-------------------------- %%
%                          本类为绘制单Y轴线图
%程序相关变量说明
%    gcf 返回当前Figure对象的句柄值
%    gca 返回当前axes对象的句柄值
%    gco 返回当前鼠标单击的句柄值
%注意：输入数据必须为元胞数组
%%-----------------------------------------------------------------%%
%% ----------------------------代码-------------------------- %% 
classdef SingleYLinePicture < handle
    properties
        %Legend设置——标签
        legends=struct('fontName','times new roman',...
                       'fontSize',20,...
                       'position','northeast',...
                       'content',[],...
                       'index_off',[]);
        %Label设置——坐标轴变量
        labels=struct('fontName','times new roman',...
                      'fontSize',20,...
                      'X','',...
                      'Y','');
        %Graduation设置——坐标刻度
        graduations=struct('fontName','times new roman',...
                           'fontSize',20,...
                           'xlim',[],...
                           'xtick',[],...
                           'ylim',[],...
                           'ytick',[],...
                           'yscale_auto','f');
        %line设置——线型
        lines=struct('style',["--k","-.k",":k","--b","-.b",":b"],...
                     'width',1,...
                     'markerSize',1,...
                     'markerNum',20);
        %Picture设置——图片
        pictures=struct('unit','pixels',...
                        'position',[200 300 1000 600],...
                        'name','Name.bmp',...
                        'format','-dbmp',...
                        'renderer','painters',...
                        'dpi','-r150');
        data=struct('X',[],...
                    'Y',[]);
    end
    methods(Static)
        %对X轴数据进行调整
        function xData=AdjustXData(xData,yData)
            xlen=length(xData);
            ylen=length(yData);
            if(xlen~=ylen)
                xData_temp=xData(1);
                xData=cell(1,ylen);
                for i=1:ylen
                    xData(i)=xData_temp;
                end
            end
        end
        %对Y轴数据数据范围进行设置，只指定下限
        function [ylim,ytick]=SetYScale()
            ylim=get(gca,'ylim');
            ytick=get(gca,'YTick');
            %数据有正有负，返回原设置范围
            if(ylim(1)*ylim(2)<=0)
                return;
            %所有数据均为负，设置上限
            elseif(ylim(1)<0 && ylim(2)<0)
                ylim(2)=0;
                set(gca,'ylim',ylim);
                ytick=get(gca,'YTick');
                deltaY=ytick(2)-ytick(1);
                ylim(1)=ytick(1)-deltaY;
                set(gca,'ylim',ylim);
                ytick=ylim(1):deltaY:ylim(2);
                return;
            %所有数据均为正，设置下限
            elseif(ylim(1)>0 && ylim(2)>0)
                ylim(1)=0;
                set(gca,'ylim',ylim);
                ytick=get(gca,'YTick');
                deltaY=ytick(2)-ytick(1);
                ylim(2)=ytick(end)+deltaY;
                set(gca,'ylim',ylim);
                ytick=ylim(1):deltaY:ylim(2);
                return;
            end
        end
    end
    methods
        %构造函数：只对相关参数进行设置，不执行与绘图相关的操作
        function obj=SingleYLinePicture(xData,yData,xLabelStr,yLabelStr,xLim,xTick,legendStr,name)
            obj.data.X=xData;
            obj.data.Y=yData;
            obj.labels.X=xLabelStr;
            obj.labels.Y=yLabelStr;
            obj.graduations.xlim=xLim;
            obj.graduations.xtick=xTick;
            obj.legends.content=legendStr;
            obj.pictures.name=name;
        end
        %保存绘制的图片
        function Save(obj)
            set(gcf,'defaultFigureRenderer',obj.pictures.renderer);   %设置默认渲染器
            print(gcf,obj.pictures.dpi,obj.pictures.format,obj.pictures.name);   %设置输出格式和dpi
        end
        function PlotPicture(obj)
            hold on
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            xData=obj.data.X;
            yData=obj.data.Y;
            ylen=length(yData);
            xData=obj.AdjustXData(xData,yData);
            for i=1:ylen
                tempX=cell2mat(xData(i));
                tempY=cell2mat(yData(i));
                if(~isempty(obj.graduations.xlim))
                    xlim_temp=obj.graduations.xlim;
                else
                    xlim_temp=[min(tempX),max(tempX)];
                end
                if(obj.lines.markerNum==0)
                    H(i)=plot(tempX,tempY,char(obj.lines.style(i)),'LineWidth',obj.lines.width,'MarkerSize',obj.lines.markerSize);
                else
                    markerIndices=FindMarkerIndices(tempX,xlim_temp,obj.lines.markerNum);
                    H(i)=plot(tempX,tempY,char(obj.lines.style(i)),'LineWidth',obj.lines.width,'MarkerIndices',markerIndices,'MarkerSize',obj.lines.markerSize);
                end
            end
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            ylabel(obj.labels.Y,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Y轴的数据显示范围
            if(isempty(obj.graduations.ylim) && isempty(obj.graduations.ytick))
                if(obj.graduations.yscale_auto=='f')
                else
                    [obj.graduations.ylim,obj.graduations.ytick]=obj.SetYScale();
                end
            else
                set(gca,'YLim',obj.graduations.ylim);
                set(gca,'YTick',obj.graduations.ytick);
            end
            %Legend设置
            if(isempty(obj.legends.index_off))
            else
                for i=1:length(obj.legends.index_off)
                    set(H(obj.legends.index_off(i)),'handlevisibility','off');
                end
            end
            if(isempty(obj.legends.content))
            else
                h=legend(obj.legends.content,'interpreter','latex','location',obj.legends.position);
                set(h,'Box','on');  % Legend文本有框框
                set(h,'fontname',obj.legends.fontName,'Fontsize',obj.legends.fontSize,'LineWidth',obj.lines.width);  %设置Legend的字体字号
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
    end
end
%%-----------------------------------------------------------------%%
