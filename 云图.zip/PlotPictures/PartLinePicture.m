%% ----------------------------说明-------------------------- %%
%                          本类为绘制局部线图
%                       主要是对原图进行局部放大
%程序相关变量说明
%    gcf 返回当前Figure对象的句柄值
%    gca 返回当前axes对象的句柄值
%    gco 返回当前鼠标单击的句柄值
%注意：输入数据必须为元胞数组
%%-----------------------------------------------------------------%%
%% ----------------------------代码-------------------------- %% 
classdef PartLinePicture < handle
    properties
        %Legend——无需设置
        %Label——无需设置
        %Graduation设置——坐标刻度
        graduations=struct('fontName','times new roman',...
                           'fontSize',20,...
                           'xlim',[]);
        %line设置——线型
        lines=struct('style',["--k","-.k",":k","--b","-.b",":b"],...
                     'width',2,...
                     'markerSize',10,...
                     'markerNum',0);
        %Picture设置——图片
        pictures=struct('position',[],...
                        'name','Name.bmp',...
                        'format','-dbmp',...
                        'renderer','painters',...
                        'dpi','-r150');
        
        data=struct('X',[],...
                    'Y',[]);
    end
    methods(Static)
        %对X轴数据进行调整
        function xData=AdjustXData(xData,yData)
            xlen=length(xData);
            ylen=length(yData);
            if(xlen~=ylen)
                xData_temp=xData(1);
                xData=cell(1,ylen);
                for i=1:ylen
                    xData(i)=xData_temp;
                end
            end
        end
    end
    methods
        %构造函数：只对相关参数进行设置，不执行与绘图相关的操作
        function obj=PartLinePicture(xData,yData,position,name)
            obj.data.X=xData;
            obj.data.Y=yData;
            obj.pictures.position=position;
            obj.pictures.name=name;
        end
        %保存绘制的图片
        function Save(obj)
            set(gcf,'defaultFigureRenderer',obj.pictures.renderer);   %设置默认渲染器
            print(gcf,obj.pictures.dpi,obj.pictures.format,obj.pictures.name);   %设置输出格式和dpi
        end
        function PlotPicture(obj)
            ax=axes('Position',obj.pictures.position);
            xData=obj.data.X;
            yData=obj.data.Y;
            ylen=length(yData);
            xData=obj.AdjustXData(xData,yData);
            hold on
            for i=1:ylen
                tempX=cell2mat(xData(i));
                tempY=cell2mat(yData(i));
                if(~isempty(obj.graduations.xlim))
                    xlim_temp=obj.graduations.xlim;
                else
                    xlim_temp=[min(tempX),max(tempX)];
                end
                if(obj.lines.markerNum==0)
                    plot(ax,tempX,tempY,char(obj.lines.style(i)),'LineWidth',obj.lines.width);
                else
                    markerIndices=FindMarkerIndices(tempX,xlim_temp,obj.lines.markerNum);
                    plot(ax,tempX,tempY,char(obj.lines.style(i)),'LineWidth',obj.lines.width,'MarkerIndices',markerIndices);
                end
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
    end
end
%%-----------------------------------------------------------------%%