%% ----------------------------说明-------------------------- %%
%                          本类为绘制极坐标系图
%程序相关变量说明
%    gcf 返回当前Figure对象的句柄值
%    gca 返回当前axes对象的句柄值
%    gco 返回当前鼠标单击的句柄值
%注意：输入数据必须为元胞数组
%%-----------------------------------------------------------------%%
%% ----------------------------代码-------------------------- %% 
classdef PolarCoordPicture < handle
    properties
        %Legend设置——标签
        legends=struct('fontName','times new roman',...
                       'fontSize',20,...
                       'position','northeast',...
                       'content',[],...
                       'index_off',[]);
        %Label设置——坐标轴变量
        labels=struct('fontName','times new roman',...
                      'fontSize',20,...
                      'theta','',...
                      'R','');
        %Graduation设置——坐标刻度及字符
        graduations=struct('fontName','times new roman',...
                           'fontSize',25,...
                           'thetaLim',[],...
                           'thetaTick',[],...
                           'thetaTickLabel',[],...
                           'RLim',[],...
                           'RTick',[],...
                           'RTickLabel',[]);
        %line设置——线型
        lines=struct('style',["--k","-.k",":k","--b","-.b",":b"],...
                     'width',3,...
                     'markerSize',1);
        %Picture设置——图片
        pictures=struct('unit','pixels',...
                        'position',[200 300 1000 600],...
                        'name','Name.bmp',...
                        'format','-dbmp',...
                        'renderer','painters',...
                        'dpi','-r150');
        data=struct('theta',[],...
                    'R',[],...
                    'V',[]);
        %colorbar
        colorBar=struct('show',true,...
                        'string','',...
                        'location','eastoutside',...
                        'TickLabelInterpreter','none',...
                        'lineNum',10,...
                        'tickLabels',[],...
                        'ticks',[]);
    end
    methods(Static)
        %对X轴数据进行调整
        function thetaData=AdjustThetaData(thetaData,RData)
            xlen=length(thetaData);
            ylen=length(RData);
            if(xlen~=ylen)
                xData_temp=thetaData(1);
                thetaData=cell(1,ylen);
                for i=1:ylen
                    thetaData(i)=xData_temp;
                end
            end
        end
    end
    methods
        %构造函数：只对相关参数进行设置，不执行与绘图相关的操作
        function obj=PolarCoordPicture(thetaData,RData,thetaLabelStr,RLabelStr,thetaLim,thetaTick,legendStr,name)
            obj.data.theta=thetaData;
            obj.data.R=RData;
            obj.labels.theta=thetaLabelStr;
            obj.labels.R=RLabelStr;
            obj.graduations.thetaLim=thetaLim;
            obj.graduations.thetaTick=thetaTick;
            obj.legends.content=legendStr;
            obj.pictures.name=name;
        end
        %保存绘制的图片
        function Save(obj)
            set(gcf,'defaultFigureRenderer',obj.pictures.renderer);   %设置默认渲染器
            print(gcf,obj.pictures.dpi,obj.pictures.format,obj.pictures.name);   %设置输出格式和dpi
        end
        %调用polarplot函数
        function PlotPicture_polarPlot(obj)
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            thetaData=obj.data.theta;
            RData=obj.data.R;
            RLen=length(RData);
            thetaData=obj.AdjustThetaData(thetaData,RData);
            for i=1:RLen
                tempTheta=cell2mat(thetaData(i));
                tempR=cell2mat(RData(i));
                polarplot(tempTheta,tempR,char(obj.lines.style(i)),'LineWidth',obj.lines.width,'MarkerSize',obj.lines.markerSize);
                hold on
            end
            ax=gca;
            ax.ThetaAxis.Label.String=obj.labels.theta;
            ax.ThetaAxis.Label.Interpreter='latex';
            ax.ThetaAxis.Label.FontName=obj.labels.fontName;
            ax.ThetaAxis.Label.FontSize=obj.labels.fontSize;
            ax.RAxis.Label.String=obj.labels.R;
            ax.RAxis.Label.Interpreter='latex';
            ax.RAxis.Label.FontName=obj.labels.fontName;
            ax.RAxis.Label.FontSize=obj.labels.fontSize;
            %theta轴的数据显示范围
            if(isempty(obj.graduations.thetaLim) && isempty(obj.graduations.thetaTick))
            else
                set(gca,'ThetaLim',obj.graduations.thetaLim);
                set(gca,'ThetaLim',obj.graduations.thetaTick);
            end
            %R轴的数据显示范围
            if(isempty(obj.graduations.RLim) && isempty(obj.graduations.RTick))
            else
                set(gca,'RLim',obj.graduations.RLim);
                set(gca,'RTick',obj.graduations.RTick);
            end
            %Legend设置
            if(isempty(obj.legends.index_off))
            else
                for i=1:length(obj.legends.index_off)
                    set(H(obj.legends.index_off(i)),'handlevisibility','off');
                end
            end
            if(isempty(obj.legends.content))
            else
                h=legend(obj.legends.content,'interpreter','latex','location',obj.legends.position);
                set(h,'Box','on');  % Legend文本有框框
                set(h,'fontname',obj.legends.fontName,'Fontsize',obj.legends.fontSize,'LineWidth',obj.lines.width);  %设置Legend的字体字号
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ThetaGrid','on','RGrid','on');  %设置图中是否显示网格
        end
        %调用polarscatter函数
        function PlotPicture_polarScatter(obj)
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            thetaData=obj.data.theta;
            RData=obj.data.R;
            VData=obj.data.V;
            RLen=length(RData);
            if(isempty(VData))
                disp("Please input the V data");
                return;
            end
            for i=1:RLen
                tempTheta=cell2mat(thetaData(i));
                tempR=cell2mat(RData(i));
                tempV=cell2mat(VData(i));
                polarscatter(tempTheta,tempR,obj.lines.markerSize,tempV);
%                 H(i).Marker=obj.lines.markerSym;
                hold on
            end
            ax=gca;
            ax.ThetaAxis.Label.String=obj.labels.theta;
            ax.ThetaAxis.Label.Interpreter='latex';
            ax.ThetaAxis.Label.FontName=obj.labels.fontName;
            ax.ThetaAxis.Label.FontSize=obj.labels.fontSize;
            ax.RAxis.Label.String=obj.labels.R;
            ax.RAxis.Label.Interpreter='latex';
            ax.RAxis.Label.FontName=obj.labels.fontName;
            ax.RAxis.Label.FontSize=obj.labels.fontSize;
            if(obj.colorBar.show==true)
                C=colorbar('location',obj.colorBar.location,'TickLabelInterpreter',obj.colorBar.TickLabelInterpreter);
                C.Label.Interpreter='latex';
                C.Label.String=obj.colorBar.string;
                C.Label.FontName=obj.labels.fontName;
                C.Label.FontSize=obj.labels.fontSize;
                C.Label.FontWeight='bold';
                C.FontName=obj.graduations.fontName;
                C.FontSize=obj.graduations.fontSize;
                C.FontWeight='bold';
                %显示范围
                if(isempty(obj.colorBar.ticks) && isempty(obj.colorBar.tickLabels))
                else
                    C.Ticks=obj.colorBar.ticks;
                    C.TickLabels=obj.graduations.tickLabels;
                end
            end
            shading interp
            %theta轴的数据显示范围
            if(isempty(obj.graduations.thetaLim) && isempty(obj.graduations.thetaTick))
            else
                set(gca,'ThetaLim',obj.graduations.thetaLim);
                set(gca,'ThetaLim',obj.graduations.thetaTick);
            end
            %R轴的数据显示范围
            if(isempty(obj.graduations.RLim) && isempty(obj.graduations.RTick))
            else
                set(gca,'RLim',obj.graduations.RLim);
                set(gca,'RTick',obj.graduations.RTick);
            end
            %Legend设置
            if(isempty(obj.legends.index_off))
            else
                for i=1:length(obj.legends.index_off)
                    set(H(obj.legends.index_off(i)),'handlevisibility','off');
                end
            end
            if(isempty(obj.legends.content))
            else
                h=legend(obj.legends.content,'interpreter','latex','location',obj.legends.position);
                set(h,'Box','on');  % Legend文本有框框
                set(h,'fontname',obj.legends.fontName,'Fontsize',obj.legends.fontSize,'LineWidth',obj.lines.width);  %设置Legend的字体字号
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ThetaGrid','on','RGrid','on');  %设置图中是否显示网格
        end
    end
end