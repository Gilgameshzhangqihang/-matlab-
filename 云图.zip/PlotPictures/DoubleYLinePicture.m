%% ----------------------------说明-------------------------- %%
%                          本类为绘制双Y轴线图
%程序相关变量说明
%    gcf 返回当前Figure对象的句柄值
%    gca 返回当前axes对象的句柄值
%    gco 返回当前鼠标单击的句柄值
%注意：输入数据必须为元胞数组
%%-----------------------------------------------------------------%%
%% ----------------------------代码-------------------------- %% 
classdef DoubleYLinePicture < handle
    properties
        %Legend设置——标签
        legends=struct('fontName','times new roman',...
                       'fontSize',20,...
                       'position','East',...
                       'content',[],...
                       'index_off',[]);
        %Label设置——坐标轴变量
        labels=struct('fontName','times new roman',...
                      'fontSize',20,...
                      'x','',...
                      'y1','',...
                      'y2','');
        %Graduation设置——坐标刻度
        graduations=struct('fontName','times new roman',...
                           'fontSize',20,...
                           'xlim',[],...
                           'xtick',[],...
                           'y1lim',[],...
                           'y1tick',[],...
                           'y2lim',[],...
                           'y2tick',[],...
                           'y1scale_auto','f',...
                           'y2scale_auto','f');
        %line设置——线型
        lines=struct('y1style',["--k","-.k",":k","--b","-.b",":b"],...
                     'y2style',["--k","-.k",":k","--b","-.b",":b"],...
                     'width',2,...
                     'markerSize',10,...
                     'markerNum',10);
        %Picture设置——图片
        pictures=struct('position',[200 300 1000 600],...
                        'name','Name.bmp',...
                        'format','-dbmp',...
                        'renderer','painters',...
                        'dpi','-r150');
        %data设置——数据
        data=struct('X1',[],...
                    'Y1',[],...
                    'X2',[],...
                    'Y2',[]);
        %axis设置——坐标轴
        axis_set=struct('color',[[0 0 1];[1 0 0]]);
    end
    methods(Static)
        %对X轴数据进行调整
        function xData=AdjustXData(xData,yData)
            xlen=length(xData);
            ylen=length(yData);
            if(xlen~=ylen)
                xData_temp=xData(1);
                xData=cell(1,ylen);
                for i=1:ylen
                    xData(i)=xData_temp;
                end
            end
        end
        %对Y轴数据数据范围进行设置，只指定下限
        function [ylim,ytick]=SetYScale()
            ylim=get(gca,'ylim');
            ytick=get(gca,'YTick');
            %数据有正有负，返回原设置范围
            if(ylim(1)*ylim(2)<=0)
                return;
            %所有数据均为负，设置上限
            elseif(ylim(1)<0 && ylim(2)<0)
                ylim(2)=0;
                set(gca,'ylim',ylim);
                ytick=get(gca,'YTick');
                deltaY=ytick(2)-ytick(1);
                ylim(1)=ytick(1)-deltaY;
                set(gca,'ylim',ylim);
                ytick=ylim(1):deltaY:ylim(2);
                return;
            %所有数据均为正，设置下限
            elseif(ylim(1)>0 && ylim(2)>0)
                ylim(1)=0;
                set(gca,'ylim',ylim);
                ytick=get(gca,'YTick');
                deltaY=ytick(2)-ytick(1);
                ylim(2)=ytick(end)+deltaY;
                set(gca,'ylim',ylim);
                ytick=ylim(1):deltaY:ylim(2);
                return;
            end
        end
    end
    methods
        %构造函数：只对相关参数进行设置，不执行与绘图相关的操作
        function obj=DoubleYLinePicture(xData1,yData1,xData2,yData2,xLabelStr,yLabelStr1,yLabelStr2,xLim,xTick,legendStr1,legendStr2,name)
            obj.data.X1=xData1;
            obj.data.Y1=yData1;
            obj.data.X2=xData2;
            obj.data.Y2=yData2;
            obj.labels.X=xLabelStr;
            obj.labels.Y1=yLabelStr1;
            obj.labels.Y2=yLabelStr2;
            obj.graduations.xlim=xLim;
            obj.graduations.xtick=xTick;
            obj.legends.content= [legendStr1;legendStr2];
            obj.pictures.name=name;
        end
        %保存绘制的图片
        function Save(obj)
            set(gcf,'defaultFigureRenderer',obj.pictures.renderer);   %设置默认渲染器
            print(gcf,obj.pictures.dpi,obj.pictures.format,obj.pictures.name);   %设置输出格式和dpi
        end
        function PlotPicture(obj)
            hold on
            set(gcf,'defaultAxesColorOrder',obj.axis_set.color);
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            x1Data=obj.data.X1;
            y1Data=obj.data.Y1;
            y1len=length(y1Data);
            x1Data=obj.AdjustXData(x1Data,y1Data);
            x2Data=obj.data.X2;
            y2Data=obj.data.Y2;
            y2len=length(y2Data);
            x2Data=obj.AdjustXData(x2Data,y2Data);
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            %激活左侧y坐标轴
            yyaxis left
            for i=1:y1len
                tempX=cell2mat(x1Data(i));
                tempY=cell2mat(y1Data(i));
                if(~isempty(obj.graduations.xlim))
                    xlim_temp=obj.graduations.xlim;
                else
                    xlim_temp=[min(tempX),max(tempX)];
                end
                if(obj.lines.markerNum==0)
                    y(i)=plot(tempX,tempY,char(obj.lines.y1style(i)),'LineWidth',obj.lines.width,'MarkerSize',obj.lines.markerSize);
                else
                    markerIndices=FindMarkerIndices(tempX,xlim_temp,obj.lines.markerNum);
                    y(i)=plot(tempX,tempY,char(obj.lines.y1style(i)),'LineWidth',obj.lines.width,'MarkerIndices',markerIndices,'MarkerSize',obj.lines.markerSize);
                end
            end
            ylabel(obj.labels.Y1,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            %设置左侧y轴显示范围
            if(isempty(obj.graduations.y1lim) && isempty(obj.graduations.y1tick))
                if(obj.graduations.y1scale_auto=='f')
                else
                    [obj.graduations.y1lim,obj.graduations.y1tick]=obj.SetYScale();
                end
            else
                set(gca,'YLim',obj.graduations.y1lim);
                set(gca,'YTick',obj.graduations.y1tick);
            end
            yyaxis right
            for i=1:y2len
                tempX=cell2mat(x2Data(i));
                tempY=cell2mat(y2Data(i));
                if(~isempty(obj.graduations.xlim))
                    xlim_temp=obj.graduations.xlim;
                else
                    xlim_temp=[min(tempX),max(tempX)];
                end
                if(obj.lines.markerNum==0)
                    y(i+y1len)=plot(tempX,tempY,char(obj.lines.y2style(i)),'LineWidth',obj.lines.width,'MarkerSize',obj.lines.markerSize);
                else
                    markerIndices=FindMarkerIndices(tempX,xlim_temp,obj.lines.markerNum);
                    y(i+y1len)=plot(tempX,tempY,char(obj.lines.y2style(i)),'LineWidth',obj.lines.width,'MarkerIndices',markerIndices,'MarkerSize',obj.lines.markerSize);
                end
            end
            ylabel(obj.labels.Y2,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            %设置右侧y轴显示范围
            if(isempty(obj.graduations.y2lim) && isempty(obj.graduations.y2tick))
                if(obj.graduations.y2scale_auto=='f')
                else
                    [obj.graduations.y2lim,obj.graduations.y2tick]=obj.SetYScale();
                end
            else
                set(gca,'YLim',obj.graduations.y2lim);
                set(gca,'YTick',obj.graduations.y2tick);
            end
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Legend设置
            if(isempty(obj.legends.index_off))
            else
                for i=1:length(obj.legends.index_off)
                    set(y(obj.legends.index_off(i)),'handlevisibility','off');
                end
            end
            if(isempty(obj.legends.content))
            else
                h=legend(obj.legends.content,'interpreter','latex','location',obj.legends.position);
                set(h,'Box','on');  % Legend文本有框框
                set(h,'fontname',obj.legends.fontName,'Fontsize',obj.legends.fontSize,'LineWidth',obj.lines.width);  %设置Legend的字体字号
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.lines.width,'FontWeight','bold');
            %图片整体设置
            set(gcf,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
    end
end
%%-----------------------------------------------------------------%%
