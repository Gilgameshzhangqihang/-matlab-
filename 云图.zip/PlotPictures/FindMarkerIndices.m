function markerIndices=FindMarkerIndices(xData,xlim,markerNum)
%根据数据长度调整markerIndices——间隔的长度相同，而非点的个数相同
    %数据总长度
    length_all=abs(xlim(2)-xlim(1));
    %间隔长度
    length_interval=length_all./(markerNum-1);
    length_interval=length_interval-length_interval/100;
    data_interval=(xlim(1):length_interval:xlim(2));
    %各间隔的起始索引
    markerIndices=zeros(1,markerNum);
    for i=1:length(markerIndices)
        markerIndices(i)=find(xData<=data_interval(i),1,'last');
    end
end