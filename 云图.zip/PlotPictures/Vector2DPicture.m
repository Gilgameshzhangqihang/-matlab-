%% ----------------------------说明-------------------------- %%
%                          本类为绘制二维向量图
%程序相关变量说明
%    gcf 返回当前Figure对象的句柄值
%    gca 返回当前axes对象的句柄值
%    gco 返回当前鼠标单击的句柄值
%注意：输入数据必须为元胞数组
%%-----------------------------------------------------------------%%
%% ----------------------------代码-------------------------- %% 
classdef Vector2DPicture < handle
    properties
        %Label设置——坐标轴变量
        labels=struct('fontName','times new roman',...
                      'fontSize',25,...
                      'X','',...
                      'Y','');
        %Graduation设置——坐标刻度
        graduations=struct('fontName','times new roman',...
                           'fontSize',25,...
                           'xlim',[],...
                           'xtick',[],...
                           'ylim',[],...
                           'ytick',[]);
        %arrow设置——箭头
        arrows=struct('scale',2,...
                      'color','r',...
                      'lineStyle','-',...
                      'lineWidth',1,...
                      'markerSym','o',...
                      'markerSize',3);
        %Picture设置——图片
        pictures=struct('unit','pixels',...
                        'position',[200 300 1000 600],...
                        'name','Name.bmp',...
                        'format','-dbmp',...
                        'renderer','painters',...
                        'dpi','-r150');
        %数据
        data=struct('X',[],...
                    'Y',[],...
                    'Vx',[],...
                    'Vy',[]);
    end
    methods
        %构造函数：只对相关参数进行设置，不执行与绘图相关的操作
        function obj=Vector2DPicture(XData,YData,VxData,VyData,xLabelStr,yLabelStr,name)
            obj.data.X=XData;
            obj.data.Y=YData;
            obj.data.Vx=VxData;
            obj.data.Vy=VyData;
            obj.labels.X=xLabelStr;
            obj.labels.Y=yLabelStr;
            obj.pictures.name=name;
        end
        %保存绘制的图片
        function Save(obj)
            set(gcf,'defaultFigureRenderer',obj.pictures.renderer);   %设置默认渲染器
            print(gcf,obj.pictures.dpi,obj.pictures.format,obj.pictures.name);   %设置输出格式和dpi
        end
        function PlotPicture_quiver(obj)
            hold on
            set(gcf,'defaultfigurecolor','w');    % 设置背景为白色
            XData=cell2mat(obj.data.X);
            YData=cell2mat(obj.data.Y);
            VxData=cell2mat(obj.data.Vx);
            VyData=cell2mat(obj.data.Vy);
            H=quiver(XData,YData,VxData,VyData,'Color',obj.arrows.color,'LineStyle',obj.arrows.lineStyle,...
                'LineWidth',obj.arrows.lineWidth,'Marker',obj.arrows.markerSym,'MarkerSize',obj.arrows.markerSize);
            H.ShowArrowHead='on';
            H.MaxHeadSize=0.2;
            H.AutoScale='on';
            H.AutoScaleFactor=obj.arrows.scale;
            axis equal
            %坐标轴标注
            xlabel(obj.labels.X,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            ylabel(obj.labels.Y,'interpreter','latex', 'fontname', obj.labels.fontName,'Fontsize',obj.labels.fontSize);
            %X轴的数据显示范围
            if(isempty(obj.graduations.xlim) && isempty(obj.graduations.xtick))
            else
                set(gca,'XLim',obj.graduations.xlim);
                set(gca,'XTick',obj.graduations.xtick);
            end
            %Y轴的数据显示范围
            if(isempty(obj.graduations.ylim) && isempty(obj.graduations.ytick))
            else
                set(gca,'YLim',obj.graduations.ylim);
                set(gca,'YTick',obj.graduations.ytick);
            end
            %设置坐标轴刻度的字号和字体
            set(gca,'FontSize',obj.graduations.fontSize,'Fontname',obj.graduations.fontName,'LineWidth',obj.arrows.lineWidth,'FontWeight','bold');
            %图片整体设置
            set(gcf,'units',obj.pictures.unit,'position',obj.pictures.position);   %设置图片的大小和位置
            set(gca,'ygrid','off','xgrid','off');  %设置图中是否显示网格
        end
    end
end
%%-----------------------------------------------------------------%%
